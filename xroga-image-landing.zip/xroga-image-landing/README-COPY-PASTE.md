# Xroga Image landing page — copy/paste package

This package is built for the current `Xroga/xroga.com` frontend architecture: Next.js App Router + TypeScript. The new route is `/image`.

## Create these files in the repository

1. `frontend/src/app/image/page.tsx`
2. `frontend/src/components/image/ImageLandingPage.tsx`
3. `frontend/src/styles/image-landing.css`

## Copy this asset folder

Copy the whole folder:

`frontend/public/image-landing/examples/`

into the same path in the Xroga repository.

The landing page uses the prompt-example images supplied in the ChatGPT conversation as the gallery/hero artwork. They are normal local static assets; the page itself is real React/CSS UI, not a screenshot background.

## Route

After committing and deploying the `frontend` project, the page resolves at:

`https://xroga.com/image`

## Generate button behavior

This landing package intentionally does not invent an image-generation backend. The hero Generate button currently preserves the prompt and sends the user to:

`/auth/signup?intent=image&prompt=...`

When the real image workspace/API route exists, replace the handoff URL in `handleSubmit()` inside `ImageLandingPage.tsx`.

## Optional SEO sitemap change

In `frontend/src/app/sitemap.ts`, add `['/image', .94, 'weekly']` beside the existing `/video`, `/crypto-builder`, and `/game-builder` marketing routes.
